inputE = function(path="http://127.0.0.1:5985/metda_project/new project31560542628/e.csv"){

  read.csv(URLencode(path))

}

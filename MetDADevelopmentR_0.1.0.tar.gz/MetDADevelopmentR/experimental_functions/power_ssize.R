# ssize_power
pacman::p_load(ssize)
